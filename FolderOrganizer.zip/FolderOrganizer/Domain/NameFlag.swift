//
//  NameFlag.swift
//  FolderOrganizer
//

import Foundation

enum NameFlag: String, Codable, Hashable {
    case suspicious
    case needsReview
}
