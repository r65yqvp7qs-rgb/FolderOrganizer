//
//  RenameImportResult.swift
//  FolderOrganizer
//

import Foundation

struct RenameImportResult {
    let rootFolderURL: URL
    let plans: [RenamePlan]
}
